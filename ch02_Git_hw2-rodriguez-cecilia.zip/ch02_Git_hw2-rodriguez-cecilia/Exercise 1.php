<?php
function Calculatehash($sentence, $hashtype){
    switch ($hashtype) {
        case 'md5':
            return md5($sentence);
    }
}




echo"choose Between md5 or sha1 to hash your phrase";
$hashtype= readline();

echo" Enter your sentence: ";
$sentence = readline();

$value =Calculatehash( $sentence, $hashtype);
echo "Your hashed value is: $value"

?>